package main

import (
	"github.com/animenotifier/notify.moe/server"
)

func main() {
	server.Main()
}
