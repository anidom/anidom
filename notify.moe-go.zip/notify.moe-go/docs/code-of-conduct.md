# Code of Conduct

* Be positive.
* Be respectful to each other.
* Realize that every person has his or her own opinion and that you should treat that opinion with respect. You do not have to agree with everyone but it’s worth thinking about their viewpoint.
* Do not spam.
* Do not advertise.
