package main

var (
	logChannel = "574579302843154442"
)
