# Patches

This directory contains database patches that are only meant to be run under certain conditions to fix bugs.