package main

func main() {
	// defer arn.Node.Close()

	// for track := range arn.StreamSoundTracks() {
	// 	if track.Created > "2018-03-09" {
	// 		continue
	// 	}

	// 	fmt.Println(track.Created, track.Title)
	// 	logEntry := arn.NewEditLogEntry(track.CreatedBy, "create", "SoundTrack", track.ID, "", "", "")
	// 	logEntry.Created = track.Created
	// 	logEntry.Save()
	// }

	// for quote := range arn.StreamQuotes() {
	// 	if quote.Created > "2018-03-09" {
	// 		continue
	// 	}

	// 	fmt.Println(quote.Created, quote.Text.English)
	// 	logEntry := arn.NewEditLogEntry(quote.CreatedBy, "create", "Quote", quote.ID, "", "", "")
	// 	logEntry.Created = quote.Created
	// 	logEntry.Save()
	// }
}
