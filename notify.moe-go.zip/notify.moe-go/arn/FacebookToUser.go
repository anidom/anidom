package arn

// FacebookToUser stores the user ID by Facebook user ID.
type FacebookToUser GoogleToUser
