# {name}

{go:header}

This library provides direct access to the Anime Notifier database. It is not an API client.

{go:footer}
