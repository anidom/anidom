package limits

const (
	DefaultTextMaxLength     = 100
	DefaultTextAreaMaxLength = 20000
	PostMinCharacters        = 5
)
