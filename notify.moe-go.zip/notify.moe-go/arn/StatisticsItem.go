package arn

// AnalyticsItem ...
type AnalyticsItem struct {
	Key   string
	Value float64
}
