package arn

// OpenGraph data
type OpenGraph struct {
	Tags map[string]string
	Meta map[string]string
}
