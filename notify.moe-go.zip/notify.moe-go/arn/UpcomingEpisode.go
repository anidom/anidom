package arn

// UpcomingEpisode is used in the user schedule.
type UpcomingEpisode struct {
	Anime   *Anime
	Episode *Episode
}
