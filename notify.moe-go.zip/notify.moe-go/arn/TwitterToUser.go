package arn

// TwitterToUser stores the user ID by Twitter user ID.
type TwitterToUser GoogleToUser
