package arn

// BotUserID is the user ID of the anime notifier bot.
const BotUserID = "3wUBnfUkR"
