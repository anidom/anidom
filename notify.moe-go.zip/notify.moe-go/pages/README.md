# Pages

This directory contains all the pages. They consist of:

* Controller (a "Get" function in .go files)
* Template (.pixy files)
* Style sheet (.scarlet files)