package upload

import (
	// We need these to decode uploaded images.
	_ "image/gif"
	_ "image/jpeg"
	_ "image/png"
)
