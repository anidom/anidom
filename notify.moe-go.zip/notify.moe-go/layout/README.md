# Layout

This directory contains the main template that is used for all HTML responses.
