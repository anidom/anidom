# Background jobs

This directory contains background jobs that run on a different server than the web server.